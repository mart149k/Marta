#include <iostream>
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

int main()
{
    // Read source image.
    Mat im_src = imread("C:\\Users\\mart1\\OneDrive\\Billeder\\76688894.jpg");
    // Four corners of the book in source image
    vector<Point2f> pts_src;
    pts_src.push_back(Point2f(0, 400));
    pts_src.push_back(Point2f(1800, 400));
    pts_src.push_back(Point2f(0, 1000));
    pts_src.push_back(Point2f(1800, 1000));


    // Four corners of the book in destination image.
    vector<Point2f> pts_dst;
    pts_dst.push_back(Point2f(0, 0));
    pts_dst.push_back(Point2f(1200, 0));
    pts_dst.push_back(Point2f(0, 1000));
    pts_dst.push_back(Point2f(1200, 1000));

    // Calculate Homography
    Mat h = findHomography(pts_src, pts_dst);

    // Output image
    Mat im_out;
    // Warp source image to destination based on homography
    warpPerspective(im_src, im_out,h,Size(1200,1000));

    // Display images
    imshow("Source Image", im_src);
    imshow("Warped Source Image", im_out);

    waitKey(0);
}
