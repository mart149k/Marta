#include "imageviewer.h"

#include <QApplication>
#include <QMainWindow>
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace cv;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ImageViewer w;
    w.setWindowTitle("Image Homography");
    w.show();
    return a.exec();
}
