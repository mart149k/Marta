#include "imageviewer.h"
#include "ui_imageviewer.h"

#include <QtWidgets>
#include <QFileDialog>
#include <QMessageBox>
#include <string>
#include <QPixmap>

#ifndef QT_NO_PRINTER
#include <QPrintDialog>
#endif

ImageViewer::ImageViewer(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ImageViewer)
{
    ui->setupUi(this);

    openAct = ui->openAct;
    printAct = ui->printAct;
    exitAct = ui->exitAct;
    zoomInAct = ui->zoomInAct;
    zoomOutAct = ui->zoomOutAct;
    normalSizeAct = ui->normalSizeAct;
    fitToWindowAct = ui->fitToWindowAct;
    aboutAct = ui->aboutAct;
    aboutQtAct = ui->aboutQtAct;

    imageLabel = new QLabel;
    imageLabel->setBackgroundRole(QPalette::Base);
    imageLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    imageLabel->setScaledContents(true);

    scrollArea = new QScrollArea;
    scrollArea->setBackgroundRole(QPalette::Dark);
    scrollArea->setWidget(imageLabel);
    setCentralWidget(scrollArea);

    setWindowTitle(tr("Image Viewer"));
    resize(500, 400);

    connect(openAct,SIGNAL(triggered()),this,SLOT(open()));
    connect(printAct, SIGNAL(triggered()), this, SLOT(print()));
    connect(exitAct, SIGNAL(triggered()), this, SLOT(close()));
    connect(zoomInAct, SIGNAL(triggered()), this, SLOT(zoomIn()));
    connect(zoomOutAct, SIGNAL(triggered()), this, SLOT(zoomOut()));
    connect(normalSizeAct, SIGNAL(triggered()), this, SLOT(normalSize()));
    connect(fitToWindowAct, SIGNAL(triggered()), this, SLOT(fitToWindow()));
    connect(aboutAct, SIGNAL(triggered()), this, SLOT(about()));
}

ImageViewer::~ImageViewer()
{
    delete ui;
}

void ImageViewer::updateActions()
{
    zoomInAct->setEnabled(!fitToWindowAct->isChecked());
    zoomOutAct->setEnabled(!fitToWindowAct->isChecked());
    normalSizeAct->setEnabled(!fitToWindowAct->isChecked());
}

void ImageViewer::scaleImage(double factor)
{
    Q_ASSERT(imageLabel->pixmap());
    scaleFactor *= factor;
    imageLabel->resize(scaleFactor * imageLabel->pixmap()->size());

    adjustScrollBar(scrollArea->horizontalScrollBar(), factor);
    adjustScrollBar(scrollArea->verticalScrollBar(), factor);

    zoomInAct->setEnabled(scaleFactor < 3.0);
    zoomOutAct->setEnabled(scaleFactor > 0.333);
}

void ImageViewer::adjustScrollBar(QScrollBar *scrollBar, double factor)
{
    scrollBar->setValue(int(factor * scrollBar->value()
                            + ((factor - 1) * scrollBar->pageStep()/2)));
}

void ImageViewer::open()
{
    std::string fileName = QFileDialog::getOpenFileName(this,
                                     tr("Open File"), QDir::currentPath()).toStdString();

    std::cout<<"Check"<<std::endl;
    cvImage = cv::imread(fileName,CV_LOAD_IMAGE_COLOR);
    if (!cvImage.data){
    qDebug("Image empty");
    }
     std::cout<<"Check"<<std::endl;
     cv::Mat displayImage;

    cv::cvtColor(cvImage,displayImage,CV_BGR2GRAY);
    cv::Mat temp(displayImage.cols, displayImage.rows, displayImage.type());
    QImage dest((const uchar *) temp.data, temp.cols, temp.rows, temp.step, QImage::Format_RGB888);
    ui->imageLabel->setPixmap(QPixmap::fromImage(dest));

    //    QImage qtImage = QImage((const uchar *) image.data,image.cols,image.rows,image.step,QImage::Format_RGB888);
    //  ui->imageLabel->setPixmap(QPixmap::fromImage(qtImage));
    //scaleFactor = 1.0;

    printAct->setEnabled(true);
    fitToWindowAct->setEnabled(true);
    updateActions();

    if (!fitToWindowAct->isChecked())
     imageLabel->adjustSize();

}

void ImageViewer::showImage(cv::Mat image){
    if (!image.data){
    qDebug("Image empty");
    }
     cv::Mat displayImage;
     cv::cvtColor(image,displayImage,CV_BGR2GRAY);
     cv::Mat temp(displayImage.cols, displayImage.rows, displayImage.type());
    QImage dest((const uchar *) temp.data, temp.cols, temp.rows, temp.step, QImage::Format_RGB888);
    ui->imageLabel->setPixmap(QPixmap::fromImage(dest));

 //    QImage qtImage = QImage((const uchar *) image.data,image.cols,image.rows,image.step,QImage::Format_RGB888);
   //  ui->imageLabel->setPixmap(QPixmap::fromImage(qtImage));
     //scaleFactor = 1.0;

     printAct->setEnabled(true);
     fitToWindowAct->setEnabled(true);
     updateActions();

     if (!fitToWindowAct->isChecked())
         imageLabel->adjustSize();

}

void ImageViewer::print()
{
    Q_ASSERT(imageLabel->pixmap());
#ifndef QT_NO_PRINTER
    QPrintDialog dialog(&printer, this);
    if (dialog.exec()) {
        QPainter painter(&printer);
        QRect rect = painter.viewport();
        QSize size = imageLabel->pixmap()->size();
        size.scale(rect.size(), Qt::KeepAspectRatio);
        painter.setViewport(rect.x(), rect.y(), size.width(), size.height());
        painter.setWindow(imageLabel->pixmap()->rect());
        painter.drawPixmap(0, 0, *imageLabel->pixmap());
    }
#endif
}

void ImageViewer::zoomIn()
{
    scaleImage(1.25);
}

void ImageViewer::zoomOut()
{
    scaleImage(0.8);
}

void ImageViewer::normalSize()
{
    imageLabel->adjustSize();
    scaleFactor = 1.0;
}

void ImageViewer::fitToWindow()
{
    bool fitToWindow = fitToWindowAct->isChecked();
    scrollArea->setWidgetResizable(fitToWindow);
    if (!fitToWindow) {
        normalSize();
    }
    updateActions();
}
void ImageViewer::about()
{
    QMessageBox::about(this, tr("About Image Viewer"),
            tr("<b>Image Viewer</b> example."));
}


